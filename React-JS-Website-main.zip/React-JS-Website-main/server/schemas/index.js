import testimonials from './testimonials'
import posts from './posts'

export const schemaTypes = [testimonials, posts]
