import {defineCliConfig} from 'sanity/cli'

export default defineCliConfig({
  api: {
    projectId: 'z5ks6rrx',
    dataset: 'production'
  }
})
